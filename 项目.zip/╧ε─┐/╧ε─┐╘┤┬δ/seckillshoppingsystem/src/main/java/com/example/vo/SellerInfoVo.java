package com.example.vo;

import com.example.entity.SellerInfo;

public class SellerInfoVo extends SellerInfo {



}