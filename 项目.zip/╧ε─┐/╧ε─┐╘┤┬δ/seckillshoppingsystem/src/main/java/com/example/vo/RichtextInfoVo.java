package com.example.vo;

import com.example.entity.RichtextInfo;

public class RichtextInfoVo extends RichtextInfo {



}