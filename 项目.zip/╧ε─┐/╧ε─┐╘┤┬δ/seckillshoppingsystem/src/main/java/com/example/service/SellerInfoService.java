package com.example.service;

import com.example.dao.SellerInfoDao;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.example.entity.SellerInfo;
import com.example.exception.CustomException;
import com.example.common.ResultCode;
import com.example.vo.SellerInfoVo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import cn.hutool.crypto.SecureUtil;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

@Service
public class SellerInfoService {

    @Resource
    private SellerInfoDao sellerInfoDao;

    public SellerInfo add(SellerInfo sellerInfo) {
        // 唯一校验
        int count = sellerInfoDao.checkRepeat("name", sellerInfo.getName(), null);
        if (count > 0) {
            throw new CustomException("1001", "用户名\"" + sellerInfo.getName() + "\"已存在");
        }
        if (StringUtils.isEmpty(sellerInfo.getPassword())) {
            // 默认密码123456
            sellerInfo.setPassword(SecureUtil.md5("123456"));
        } else {
            sellerInfo.setPassword(SecureUtil.md5(sellerInfo.getPassword()));
        }
        sellerInfoDao.insertSelective(sellerInfo);
        return sellerInfo;
    }

    public void delete(Long id) {
        sellerInfoDao.deleteByPrimaryKey(id);
    }

    public void update(SellerInfo sellerInfo) {
        sellerInfoDao.updateByPrimaryKeySelective(sellerInfo);
    }

    public SellerInfo findById(Long id) {
        return sellerInfoDao.selectByPrimaryKey(id);
    }

    public List<SellerInfoVo> findAll() {
        return sellerInfoDao.findByName("all");
    }

    public PageInfo<SellerInfoVo> findPage(String name, Integer pageNum, Integer pageSize, HttpServletRequest request) {
        PageHelper.startPage(pageNum, pageSize);
        List<SellerInfoVo> all = sellerInfoDao.findByName(name);
        return PageInfo.of(all);
    }

    public SellerInfoVo findByUserName(String name) {
        return sellerInfoDao.findByUsername(name);
    }

    public SellerInfo login(String username, String password) {
        SellerInfo sellerInfo = sellerInfoDao.findByUsername(username);
        if (sellerInfo == null) {
            throw new CustomException(ResultCode.USER_ACCOUNT_ERROR);
        }
        if (!SecureUtil.md5(password).equalsIgnoreCase(sellerInfo.getPassword())) {
            throw new CustomException(ResultCode.USER_ACCOUNT_ERROR);
        }
        return sellerInfo;
    }

}
