/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : seckillshoppingsystem

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2020-11-04 02:10:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin_info
-- ----------------------------
DROP TABLE IF EXISTS `admin_info`;
CREATE TABLE `admin_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `nickName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `age` int(10) DEFAULT NULL COMMENT '年龄',
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '生日',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '编号',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `cardId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证',
  `account` double(10,2) DEFAULT NULL COMMENT '余额',
  `level` int(10) NOT NULL DEFAULT '1' COMMENT '权限等级',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='管理员信息表';

-- ----------------------------
-- Records of admin_info
-- ----------------------------
INSERT INTO `admin_info` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '22', '2020-11-02 00:04:25', '18843232356', '上海市2', '111', 'aa@163.com', '342425199001116372', '100.00', '1');
INSERT INTO `admin_info` VALUES ('2', 'admin2', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '23', '2020-11-02 00:04:25', '18843232356', '北京市', '222', 'bb@163.com', '342425199001116376', '0.00', '1');
INSERT INTO `admin_info` VALUES ('3', 'admin3', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '女', '32', '2020-11-02 00:04:25', '18843232356', '合肥市', '333', 'cc@163.com', '342425199001116323', '0.00', '1');
INSERT INTO `admin_info` VALUES ('4', 'admin4', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '女', '24', '2020-11-02 00:04:25', '18843232356', '北京市', '444', 'hahaha@126.com', '342425199001116837', '0.00', '1');
INSERT INTO `admin_info` VALUES ('5', 'admin5', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '25', '2020-11-02 00:04:25', '18843232356', '合肥市', '555', 'hello@126.com', '342425199001116309', '0.00', '1');
INSERT INTO `admin_info` VALUES ('6', 'admin6', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '26', '2020-11-02 00:04:25', '18843232356', '北京市', '666', '1212@qq.com', '342425199001116984', '0.00', '1');
INSERT INTO `admin_info` VALUES ('7', 'admin7', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '21', '2020-11-02 00:04:25', '18843232356', '合肥市', '777', '8765@qq.com', '342425199001116303', '0.00', '1');
INSERT INTO `admin_info` VALUES ('8', 'admin8', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '31', '2020-11-02 00:04:25', '18843232356', '北京市', '888', '9080@qq.com', '342425199001116910', '0.00', '1');
INSERT INTO `admin_info` VALUES ('9', 'admin9', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '男', '34', '2020-11-02 00:04:25', '18843232356', '合肥市', '999', 'shjs@126.com', '342425199001116345', '0.00', '1');
INSERT INTO `admin_info` VALUES ('10', 'admin10', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '女', '33', '2020-11-02 00:04:25', '18843232356', '深圳市', '000', '666@qq.com', '342425199001116234', '0.00', '1');

-- ----------------------------
-- Table structure for advertiser_info
-- ----------------------------
DROP TABLE IF EXISTS `advertiser_info`;
CREATE TABLE `advertiser_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公告名称',
  `content` longtext COLLATE utf8mb4_unicode_ci COMMENT '公告内容',
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公告时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='公告信息表';

-- ----------------------------
-- Records of advertiser_info
-- ----------------------------
INSERT INTO `advertiser_info` VALUES ('1', '系统公告22222222', '<p>这是系统公告，管理员可以在后台修改2222222222</p>', '2020-11-04 02:02:14');
INSERT INTO `advertiser_info` VALUES ('2', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('3', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('4', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('5', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('6', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('7', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('8', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('9', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');
INSERT INTO `advertiser_info` VALUES ('10', '系统公告', '这是系统公告，管理员可以在后台修改', '2020-11-02 00:04:25');

-- ----------------------------
-- Table structure for cart_info
-- ----------------------------
DROP TABLE IF EXISTS `cart_info`;
CREATE TABLE `cart_info` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '数量',
  `goodsId` bigint(10) NOT NULL DEFAULT '0' COMMENT '所属商品',
  `userId` bigint(10) NOT NULL DEFAULT '0' COMMENT '所属用户',
  `level` int(10) DEFAULT NULL COMMENT '用户等级',
  `createTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='购物车信息表';

-- ----------------------------
-- Records of cart_info
-- ----------------------------

-- ----------------------------
-- Table structure for comment_info
-- ----------------------------
DROP TABLE IF EXISTS `comment_info`;
CREATE TABLE `comment_info` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '评价内容',
  `goodsId` bigint(10) NOT NULL DEFAULT '0' COMMENT '所属商品',
  `userId` bigint(10) NOT NULL DEFAULT '0' COMMENT '评价人id',
  `level` int(10) DEFAULT NULL COMMENT '用户等级',
  `createTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品评价表';

-- ----------------------------
-- Records of comment_info
-- ----------------------------
INSERT INTO `comment_info` VALUES ('1', '好吃 哈哈哈', '3', '1', '3', '2020-11-04 02:04:04');

-- ----------------------------
-- Table structure for goods_info
-- ----------------------------
DROP TABLE IF EXISTS `goods_info`;
CREATE TABLE `goods_info` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商品名称',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '商品描述',
  `price` double(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `discount` double(10,2) DEFAULT '1.00' COMMENT '商品折扣',
  `sales` int(10) NOT NULL DEFAULT '0' COMMENT '商品销量',
  `hot` int(10) NOT NULL DEFAULT '0' COMMENT '商品点赞数',
  `recommend` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '否' COMMENT '是否是推荐',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '商品库存',
  `typeId` bigint(20) NOT NULL DEFAULT '0' COMMENT '所属类别',
  `fileIds` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商品图片id，用英文逗号隔开',
  `userId` bigint(10) NOT NULL DEFAULT '0' COMMENT '评价人id',
  `level` int(10) DEFAULT NULL COMMENT '用户等级',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品详情表';

-- ----------------------------
-- Records of goods_info
-- ----------------------------
INSERT INTO `goods_info` VALUES ('1', '苹果', '这是苹果', '20.00', '0.80', '31', '8', '是', '199', '1', '[12]', '1', '1');
INSERT INTO `goods_info` VALUES ('2', '戴尔', '这是戴尔', '20.00', '0.80', '10', '2', '是', '200', '2', '[13]', '1', '1');
INSERT INTO `goods_info` VALUES ('3', '零食1', '这是零食1', '20.00', '0.80', '23', '6', '否', '197', '3', '[14]', '1', '1');
INSERT INTO `goods_info` VALUES ('4', '安踏羽绒服', '这是安踏羽绒服', '100.00', '0.80', '0', '0', '是', '100', '5', '[16, 15, 17]', '1', '1');

-- ----------------------------
-- Table structure for message_info
-- ----------------------------
DROP TABLE IF EXISTS `message_info`;
CREATE TABLE `message_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '留言名称',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '留言内容',
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '留言时间',
  `parentId` bigint(20) DEFAULT '0' COMMENT '父id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='留言信息表';

-- ----------------------------
-- Records of message_info
-- ----------------------------
INSERT INTO `message_info` VALUES ('1', 'admin', '来了', '2020-11-04 02:02:26', '0');
INSERT INTO `message_info` VALUES ('2', 'admin', '1111', '2020-11-04 02:02:29', '1');
INSERT INTO `message_info` VALUES ('3', '张天志', '2222222222', '2020-11-04 02:02:49', '1');

-- ----------------------------
-- Table structure for nx_system_file_info
-- ----------------------------
DROP TABLE IF EXISTS `nx_system_file_info`;
CREATE TABLE `nx_system_file_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `originName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原始文件名',
  `fileName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '存储文件名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文件信息表';

-- ----------------------------
-- Records of nx_system_file_info
-- ----------------------------
INSERT INTO `nx_system_file_info` VALUES ('12', '44.jpg', '441604426222963.jpg');
INSERT INTO `nx_system_file_info` VALUES ('13', '77.jpg', '771604426253283.jpg');
INSERT INTO `nx_system_file_info` VALUES ('14', '100.jpg', '1001604426269854.jpg');
INSERT INTO `nx_system_file_info` VALUES ('15', '66.jpg', '661604426765665.jpg');
INSERT INTO `nx_system_file_info` VALUES ('16', '55.jpg', '551604426765663.jpg');
INSERT INTO `nx_system_file_info` VALUES ('17', '44.jpg', '441604426765661.jpg');

-- ----------------------------
-- Table structure for order_goods_rel
-- ----------------------------
DROP TABLE IF EXISTS `order_goods_rel`;
CREATE TABLE `order_goods_rel` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `orderId` bigint(20) DEFAULT NULL COMMENT '订单ID',
  `goodsId` bigint(10) NOT NULL DEFAULT '0' COMMENT '所属商品',
  `count` int(11) DEFAULT NULL COMMENT '商品数量',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订单商品关系映射表';

-- ----------------------------
-- Records of order_goods_rel
-- ----------------------------
INSERT INTO `order_goods_rel` VALUES ('1', '1', '1', '30');
INSERT INTO `order_goods_rel` VALUES ('2', '2', '2', '10');
INSERT INTO `order_goods_rel` VALUES ('3', '3', '3', '20');
INSERT INTO `order_goods_rel` VALUES ('4', '4', '3', '3');
INSERT INTO `order_goods_rel` VALUES ('5', '4', '1', '1');

-- ----------------------------
-- Table structure for order_info
-- ----------------------------
DROP TABLE IF EXISTS `order_info`;
CREATE TABLE `order_info` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `orderId` bigint(20) DEFAULT NULL COMMENT '订单ID',
  `totalPrice` double(10,2) NOT NULL DEFAULT '0.00' COMMENT '总价格',
  `userId` bigint(10) NOT NULL DEFAULT '0' COMMENT '所属用户',
  `level` int(10) DEFAULT NULL COMMENT '用户等级',
  `linkAddress` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '联系地址',
  `linkPhone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '联系电话',
  `linkMan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '联系人',
  `createTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建时间',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '未发货' COMMENT '订单状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品订单信息表';

-- ----------------------------
-- Records of order_info
-- ----------------------------
INSERT INTO `order_info` VALUES ('1', '111111', '480.00', '1', '1', '安徽省合肥市高新区', '18812337865', 'admin', '2020-11-02 00:04:25', '完成');
INSERT INTO `order_info` VALUES ('2', '222222', '160.00', '2', '2', '上海市浦东新区', '18812337865', '张三', '2020-11-02 00:04:25', '完成');
INSERT INTO `order_info` VALUES ('3', '333333', '320.00', '3', '3', '上海市长宁区', '18812337865', '李四', '2020-11-02 00:04:25', '完成');
INSERT INTO `order_info` VALUES ('4', '12020110402036543', '64.00', '1', '3', '上海市', '18843232356', '老张', '2020-11-04 02:03:08', '完成');

-- ----------------------------
-- Table structure for richtext_info
-- ----------------------------
DROP TABLE IF EXISTS `richtext_info`;
CREATE TABLE `richtext_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `content` longtext COLLATE utf8mb4_unicode_ci COMMENT '公告内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户上传信息表';

-- ----------------------------
-- Records of richtext_info
-- ----------------------------

-- ----------------------------
-- Table structure for seller_info
-- ----------------------------
DROP TABLE IF EXISTS `seller_info`;
CREATE TABLE `seller_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `nickName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `age` int(10) DEFAULT NULL COMMENT '年龄',
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '生日',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `cardId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证',
  `account` double(10,2) DEFAULT NULL COMMENT '余额',
  `level` int(10) NOT NULL DEFAULT '2' COMMENT '权限等级',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='卖家信息表';

-- ----------------------------
-- Records of seller_info
-- ----------------------------
INSERT INTO `seller_info` VALUES ('1', '张天志', 'e10adc3949ba59abbe56e057f20f883e', '老张', '男', '22', '2020-11-02 00:04:25', '18843232356', '上海市', 'aa@163.com', '342425199001116372', '0.00', '2');
INSERT INTO `seller_info` VALUES ('2', '赵千里', 'e10adc3949ba59abbe56e057f20f883e', '老赵', '男', '23', '2020-11-02 00:04:25', '18843232356', '北京市', 'bb@163.com', '342425199001116376', '0.00', '2');
INSERT INTO `seller_info` VALUES ('3', '钱优优', 'e10adc3949ba59abbe56e057f20f883e', '老钱', '女', '32', '2020-11-02 00:04:25', '18843232356', '合肥市', 'cc@163.com', '342425199001116323', '0.00', '2');
INSERT INTO `seller_info` VALUES ('4', '贾宏鑫', 'e10adc3949ba59abbe56e057f20f883e', '老贾', '女', '24', '2020-11-02 00:04:25', '18843232356', '北京市', 'hahaha@126.com', '342425199001116837', '0.00', '2');
INSERT INTO `seller_info` VALUES ('5', '夏其林', 'e10adc3949ba59abbe56e057f20f883e', '老夏', '男', '25', '2020-11-02 00:04:25', '18843232356', '合肥市', 'hello@126.com', '342425199001116309', '0.00', '2');
INSERT INTO `seller_info` VALUES ('6', '倪标生', 'e10adc3949ba59abbe56e057f20f883e', '老倪', '男', '26', '2020-11-02 00:04:25', '18843232356', '北京市', '1212@qq.com', '342425199001116984', '0.00', '2');
INSERT INTO `seller_info` VALUES ('7', '孙晓哈', 'e10adc3949ba59abbe56e057f20f883e', '老孙', '男', '21', '2020-11-02 00:04:25', '18843232356', '合肥市', '8765@qq.com', '342425199001116303', '0.00', '2');
INSERT INTO `seller_info` VALUES ('8', '李锐', 'e10adc3949ba59abbe56e057f20f883e', '老李', '男', '31', '2020-11-02 00:04:25', '18843232356', '北京市', '9080@qq.com', '342425199001116910', '0.00', '2');
INSERT INTO `seller_info` VALUES ('9', '吴腊苏', 'e10adc3949ba59abbe56e057f20f883e', '老吴', '男', '34', '2020-11-02 00:04:25', '18843232356', '合肥市', 'shjs@126.com', '342425199001116345', '0.00', '2');
INSERT INTO `seller_info` VALUES ('10', '潘晓章', 'e10adc3949ba59abbe56e057f20f883e', '老潘', '女', '33', '2020-11-02 00:04:25', '18843232356', '深圳市', '666@qq.com', '342425199001116234', '0.00', '2');

-- ----------------------------
-- Table structure for type_info
-- ----------------------------
DROP TABLE IF EXISTS `type_info`;
CREATE TABLE `type_info` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型名称',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '类型描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品类别表';

-- ----------------------------
-- Records of type_info
-- ----------------------------
INSERT INTO `type_info` VALUES ('1', '手机', '这是手机');
INSERT INTO `type_info` VALUES ('2', '电脑', '这是电脑');
INSERT INTO `type_info` VALUES ('3', '零食', '这是零食');
INSERT INTO `type_info` VALUES ('5', '衣服', '这是衣服类别');

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `nickName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `age` int(10) DEFAULT NULL COMMENT '年龄',
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '生日',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `cardId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证',
  `account` double(10,2) DEFAULT NULL COMMENT '余额',
  `level` int(10) NOT NULL DEFAULT '3' COMMENT '权限等级',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户信息表';

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES ('1', '张天志', 'e10adc3949ba59abbe56e057f20f883e', '老张', '男', '22', '2020-11-02 00:04:25', '18843232356', '上海市2', 'aa@163.com', '342425199001116372', '36.00', '3');
INSERT INTO `user_info` VALUES ('2', '赵千里', 'e10adc3949ba59abbe56e057f20f883e', '老赵', '男', '23', '2020-11-02 00:04:25', '18843232356', '北京市', 'bb@163.com', '342425199001116376', '0.00', '3');
INSERT INTO `user_info` VALUES ('3', '钱优优', 'e10adc3949ba59abbe56e057f20f883e', '老钱', '女', '32', '2020-11-02 00:04:25', '18843232356', '合肥市', 'cc@163.com', '342425199001116323', '0.00', '3');
INSERT INTO `user_info` VALUES ('4', '贾宏鑫', 'e10adc3949ba59abbe56e057f20f883e', '老贾', '女', '24', '2020-11-02 00:04:25', '18843232356', '北京市', 'hahaha@126.com', '342425199001116837', '0.00', '3');
INSERT INTO `user_info` VALUES ('5', '夏其林', 'e10adc3949ba59abbe56e057f20f883e', '老夏', '男', '25', '2020-11-02 00:04:25', '18843232356', '合肥市', 'hello@126.com', '342425199001116309', '0.00', '3');
INSERT INTO `user_info` VALUES ('6', '倪标生', 'e10adc3949ba59abbe56e057f20f883e', '老倪', '男', '26', '2020-11-02 00:04:25', '18843232356', '北京市', '1212@qq.com', '342425199001116984', '0.00', '3');
INSERT INTO `user_info` VALUES ('7', '孙晓哈', 'e10adc3949ba59abbe56e057f20f883e', '老孙', '男', '21', '2020-11-02 00:04:25', '18843232356', '合肥市', '8765@qq.com', '342425199001116303', '0.00', '3');
INSERT INTO `user_info` VALUES ('8', '李锐', 'e10adc3949ba59abbe56e057f20f883e', '老李', '男', '31', '2020-11-02 00:04:25', '18843232356', '北京市', '9080@qq.com', '342425199001116910', '0.00', '3');
INSERT INTO `user_info` VALUES ('9', '吴腊苏', 'e10adc3949ba59abbe56e057f20f883e', '老吴', '男', '34', '2020-11-02 00:04:25', '18843232356', '合肥市', 'shjs@126.com', '342425199001116345', '0.00', '3');
INSERT INTO `user_info` VALUES ('10', '潘晓章', 'e10adc3949ba59abbe56e057f20f883e', '老潘', '女', '33', '2020-11-02 00:04:25', '18843232356', '深圳市', '666@qq.com', '342425199001116234', '0.00', '3');
